// DetailModal.js
import React from 'react';

const DetailModal = ({ visible, onClose, title, details }) => {
  return (
    <div className={`modal ${visible ? 'show' : 'hide'}`}>
      <div className="modal-content">
        <span className="close" onClick={onClose}>&times;</span>
        <h2>{title}</h2>
        <p>{details}</p>
      </div>
    </div>
  );
};

export default DetailModal;
