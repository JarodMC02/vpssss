import React from 'react'

import Analytics from '../../../dashboard/analytics'

export default function PageLayoutsHorizontal() {
    return (
        <Analytics />
    )
}
