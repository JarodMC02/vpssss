import React from 'react'

import Analytics from '../../../dashboard/analytics'

export default function PageLayoutsVertical() {
    return (
        <Analytics />
    )
}
