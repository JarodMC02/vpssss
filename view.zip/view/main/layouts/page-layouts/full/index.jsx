import React from 'react'

import Analytics from '../../../dashboard/analytics'

export default function PageLayoutsFull() {
    return (
        <div className="hp-p-32 hp-bg-black-20 hp-bg-dark-90">
            <Analytics />
        </div>
    )
}
