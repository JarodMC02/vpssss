import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './ReferralLinkGenerator.css'; // Archivo de estilos personalizados
import { useSelector } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCopy } from '@fortawesome/free-solid-svg-icons';
import { Table, Button, message, Form, Input, Card, Progress } from "antd";

const ReferralLinkGenerator = () => {
  const userData = useSelector((state) => state.userData.userData);
  const [referralLink, setReferralLink] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false); // Estado para mostrar/ocultar el modal
 
  useEffect(() => {
    if (!userData || !userData.user_id) {
      setError('Datos de usuario inválidos.');
      return;
    }

    setLoading(true);
    const domain = 'billionsoffice.com'; // Reemplaza con tu dominio real
    const uniqueReferralLink = `https://${domain}/register/${userData.username}`;
    setReferralLink(uniqueReferralLink);
    setLoading(false);
  }, [userData]);

  const copyToClipboard = () => {
    if (referralLink) {
      navigator.clipboard.writeText(referralLink)
        .then(() => {
          setShowModal(true); // Mostrar el modal al copiar el enlace
        })
        .catch((err) => {
          console.error('Error al copiar el enlace: ', err);
        });
    }
  };

  const closeModal = () => {
    setShowModal(false); // Ocultar el modal al hacer clic en "Cerrar"
  };
  const handlePositionChange = async (newPos) => {
    try {
      const response = await axios.post('/pos_change', {
        userId: userData ? userData.user_id : '',
        newPosition: newPos,
      });

      if (response.status === 200) {
        message.success('Posición actualizada con éxito');
        // Set any additional state or perform other actions after the update
      } else {
        message.error('Error al actualizar la posición');
        // Handle errors appropriately
      }
    } catch (error) {
      message.error('Error en la solicitud: ' + error.message);
      // Handle network or other errors
    }
  };

  return (
    <div className="container">
    <div className="referral-link-generator">
      <h2>Generador de Enlaces de Referidos</h2>
      {loading && <p>Cargando...</p>}
      {error && <p>Error: {error}</p>}
      {referralLink && !loading && !error && (
        <div className="referral-link-container">
          <p>Aquí está tu enlace de referidos:</p>
          
          {/* Replace the text with the FontAwesome icon */}
          <button className="btn btn-primary" onClick={copyToClipboard}>
            <FontAwesomeIcon icon={faCopy} /> Copiar al Portapapeles
          </button>

          <input type="text" value={referralLink} readOnly className="form-control" />
          <button className="btn btn-secondary" onClick={() => handlePositionChange('left')}>
          Botón Izquierdo
        </button>
        <button className="btn btn-secondary" onClick={() => handlePositionChange('right')}>
          Botón Derecho
        </button>
        </div>
      )}



        {/* Modal */}
        {showModal && (
          <div className="modal fade show" tabIndex="-1" role="dialog">
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Link de Referido Exito</h5>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                    onClick={closeModal}
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <p>Usuario: {userData.username}</p>
                  <p>Enlace copiado al portapapeles.</p>
                </div>
                <div className="modal-footer">
               
                </div>
              </div>
            </div>
          </div>
        )}
        {/* Fin del modal */}
      </div>
    </div>
  );
};

export default ReferralLinkGenerator;