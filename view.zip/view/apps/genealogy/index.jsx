import React, { useState, useEffect } from "react";
import Tree from 'react-d3-tree';
import AxiosInstance from "../../../../src/axiosInstance";
import { Layout, Row, Col, Card, Table } from "antd";
import 'bootstrap/dist/css/bootstrap.min.css'; // Importar estilos de Bootstrap
import './style.css';
import { Badge } from "antd";
// Redux
import { useSelector, useDispatch } from "react-redux";

//ICONO VALIDACION
import { CheckCircleFilled, CloseCircleFilled } from "@ant-design/icons";


const { Content } = Layout;
const nodeSize = { x: 200, y: 80 };

export default function Calendar() {
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.userData.userData);

  const [treeData, setTreeData] = useState(null);
  const [binaryData, setBinaryData] = useState(null);
  const [contadorUsuariosIzquierdo, setContadorUsuariosIzquierdo] = useState(0);
  const [contadorUsuariosDerecho, setContadorUsuariosDerecho] = useState(0);


  //PARA TOTAL 
  const [totalUsuarios, setTotalUsuarios] = useState(0);
  const [totalUsuariosIzquierdo, setTotalUsuariosIzquierdo] = useState(0);
  const [totalUsuariosDerecho, setTotalUsuariosDerecho] = useState(0);
  //PARA EL ICON ENABLED
  const ApprovedIcon = () => <CheckCircleFilled style={{ color: 'green' }} />;
  const RejectedIcon = () => <CloseCircleFilled style={{ color: 'red' }} />;
 
  const renderStateIcon = (state, isActive) => {
    if (isActive && state === "approved") {
      return <Badge status="success" text="Verificado" />;
    } else if (!isActive && state === "rejected") {
      return <Badge status="error" text="No Verificado" />;
    } else {
      return null; // You can customize this for other states or when no badge is needed
    }
  };
  const sumValues = (node) => {
    if (!node.children || node.children.length === 0) {
      return node.attributes.value || 0;
    }
    return node.attributes.value + node.children.reduce((acc, child) => acc + sumValues(child), 0);
  };

  const updateTotalValue = (node) => {
    node.attributes.value = sumValues(node);
  };

  const [binarydatos, setData] = useState(false);

  useEffect(() => {
    AxiosInstance.get(`/api/datos/${userData ? userData.user_id : ""}`)
      .then((response) => {
        setData(response.data);
        console.log("ESTOS SON LOS DATOS OBTENIDOS" + userData.user_id);
      })
      .catch((error) => {
        console.error('Error al obtener datos:', error);
      });
  }, []);

  useEffect(() => {
    AxiosInstance.get(`/arbol/${userData.user_id}`)
      .then((response) => {
        const treeData = {
          name: userData.username.toString(),
          children: [],
        };

        let totalCostoPaquetesIzquierdo = 0;
        let totalCostoPaquetesDerecho = 0;

        setContadorUsuariosIzquierdo(0);
        setContadorUsuariosDerecho(0);

        if (response.data && response.data.usuarios) {
          totalCostoPaquetesIzquierdo = response.data.totalCostoPaquetesIzquierdo;
          totalCostoPaquetesDerecho = response.data.totalCostoPaquetesDerecho;

          
          function construirArbol(usuario, nivel, esLadoIzquierdoReferente) {
           // Usage in usuarioNode
          const isActive = true; // Replace this with the actual condition for user activity
          const usuarioNode = {
            name: (
              <>
                {usuario.name} {renderStateIcon(usuario.state, isActive)}{" "}
                {usuario.packDescription ? ` (B${usuario.packDescription.match(/\d+/)})` : ""}
              </>
            ),
            emoji: "🌳",
            position: usuario.position,
            user_id: usuario.user_id,
            paquetesAdquiridos: usuario.paquetesAdquiridos,
            state: usuario.state,
            children: [],
          };
            if (nivel > 0) {
              if (usuario.referidos) {
                const referidosLadoIzquierdo = usuario.referidos.filter(referido => referido.position === 1);
                const referidosLadoDerecho = usuario.referidos.filter(referido => referido.position === 2);

                if (referidosLadoIzquierdo.length === 0) {
                  const nodoVacioIzquierdo = {
                    name: "DISPONIBLE",
                    emoji: '🌳',
                    children: [],
                  };
                  usuarioNode.children.unshift(nodoVacioIzquierdo);
                }

                if (referidosLadoDerecho.length === 0) {
                  const nodoVacioDerecho = {
                    name: "DISPONIBLE",
                    emoji: '🌳',
                    children: [],
                  };
                  usuarioNode.children.push(nodoVacioDerecho);
                }

                const esLadoIzquierdoReferido = usuario.position === 1;

                if (esLadoIzquierdoReferente) {
                  referidosLadoIzquierdo.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.unshift(referidoNode);
                      setContadorUsuariosIzquierdo((prevContador) => prevContador + 1);
                    }
                  });

                  referidosLadoDerecho.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.push(referidoNode);
                      setContadorUsuariosDerecho((prevContador) => prevContador + 1);
                    }
                  });
                } else {
                  referidosLadoDerecho.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.push(referidoNode);
                      setContadorUsuariosDerecho((prevContador) => prevContador + 1);
                    }
                  });

                  referidosLadoIzquierdo.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.unshift(referidoNode);
                      setContadorUsuariosIzquierdo((prevContador) => prevContador + 1);
                    }
                  });
                }
              }
            }

            return usuarioNode;
          }

          const nivelProfundidadDeseado = 100;
          response.data.usuarios.forEach((usuario) => {
            const usuarioNode = construirArbol(usuario, nivelProfundidadDeseado, false);
            if (usuarioNode) {
              treeData.children.unshift(usuarioNode);
            }
          });
        }

        setTreeData(treeData);

        const updatedBinaryData = [
          {
            key: "2",
            left: totalCostoPaquetesIzquierdo,
            center: "VOLUMEN DE RANGO",
            right: totalCostoPaquetesDerecho,
            total: totalCostoPaquetesIzquierdo + totalCostoPaquetesDerecho,
          },
        ];
        

        setBinaryData(updatedBinaryData);
      })
      .catch((error) => {
        console.error('Error al obtener el árbol binario:', error);
      });
  }, [userData]);

  const columns = [
    {
      title: "IZQUIERDA",
      dataIndex: "left",
      key: "left",
      align: "center",
    },
    {
      title: "ESTADÍSTICAS DE LA RED",
      dataIndex: "center",
      key: "center",
      align: "center",
    },
    {
      title: "DERECHA",
      dataIndex: "right",
      key: "right",
      align: "center",
    },
    {
    title: "TOTAL",
    dataIndex: "total",
    key: "total",
    align: "center",
  },
  ];

  return (
    <Layout className="hp-calendar mt-4 mb-32 bg-dark-90">
      <Content>
        <Card>
     
        <Row className="mt-4">
            <Col span={8}>
              <h3>Total de Usuarios Izquierdo: {contadorUsuariosIzquierdo}</h3>
            </Col>
            <Col span={8}>
              <h3>Total de Usuarios Derecho: {contadorUsuariosDerecho}</h3>
            </Col>
            <Col span={8}>
              <h3>Total de Usuarios: {totalUsuarios}</h3>
            </Col>
          </Row>

          <Table
            columns={columns}
            dataSource={binaryData}
            pagination={false}
            bordered={false}
            className="mt-4"
          />

          <div style={{ width: '100%', height: '500px' }} className="mt-4">
            {treeData ? (
              <Tree
                data={treeData}
                orientation="vertical"
                initialDepth={2}
                nodeSize={nodeSize}
                allowForeignObjects
                translate={{ x: 50, y: 50 }}
                collapsible={true}
                scaleExtent={{ min: 0.1, max: 1.5 }}
                separation={{ siblings: 1.5, nonSiblings: 2 }}
                pathFunc="step"
                transitionDuration={500}
                nodeSvgShape={{
                  shape: 'none',
                }}
                rootNodeClassName="node__root"
                branchNodeClassName="node__branch"
                leafNodeClassName="node__leaf"
               
              />
            ) : (
              <p>Cargando datos del árbol...</p>
            )}
          </div>
        </Card>
      </Content>
    </Layout>
  );
}
