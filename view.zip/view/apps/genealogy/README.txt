import React, { useState, useEffect } from "react";
import Tree from 'react-d3-tree';
import AxiosInstance from "../../../../src/axiosInstance"; // Importa tu instancia de Axios

import { Layout, Row, Col, Card, Button, Drawer, Table, message, Tooltip } from "antd";
import './style.css';

// Redux
import { useSelector, useDispatch } from "react-redux";

const { Sider, Content } = Layout;
const nodeSize = { x: 200, y: 80 };
export default function Calender() {
  // Redux
  const dispatch = useDispatch();

  const userData = useSelector((state) => state.userData.userData);
  const [treeData, setTreeData] = useState(null);
  const [binaryData, setBinaryData] = useState(null);

  const sumValues = (node) => {
    if (!node.children || node.children.length === 0) {
      return node.attributes.value || 0;
    }
    return node.attributes.value + node.children.reduce((acc, child) => acc + sumValues(child), 0);
  };


  const updateTotalValue = (node) => {
    node.attributes.value = sumValues(node);
  };
  
  const [binarydatos,setData] = useState(false)
  useEffect(() => {
    AxiosInstance.get(/api/datos/${userData ? userData.user_id : ""})
      .then((response) => {
        setData(response.data);
        console.log("ESTOS SON  LOS DATOS OBTENIDOS"+userData.user_id)
      })
      .catch((error) => {
        console.error('Error al obtener datos:', error);
      });
  }, []);
 

  
  
  useEffect(() => {
    // Realiza una solicitud GET para obtener los datos del árbol binario
    AxiosInstance.get(/arbol/${userData.user_id})
      .then((response) => {
        // La respuesta debe contener los datos en el formato que deseas
        const treeData = {
          name: userData.username.toString(), // El nombre de la raíz es el ID del usuario actual
          children: [],
        };

        let totalCostoPaquetesIzquierdo = 0;
        let totalCostoPaquetesDerecho = 0;
        let totalUsuariosConPaquetesIzquierdo = 0;
        let totalUsuariosConPaquetesDerecho = 0;

        if (response.data && response.data.usuarios) {

           totalCostoPaquetesIzquierdo = response.data.totalCostoPaquetesIzquierdo;
           totalCostoPaquetesDerecho = response.data.totalCostoPaquetesDerecho;
           totalUsuariosConPaquetesIzquierdo = response.data.totalUsuariosConPaquetesIzquierdo
           totalUsuariosConPaquetesDerecho =  response.data.totalUsuariosConPaquetesDerecho
          // Función recursiva para construir el árbol con profundidad limitada
          function construirArbol(usuario, nivel, esLadoIzquierdoReferente) {

            const usuarioNode = {
              name: ${usuario.name} ${usuario.packDescription ? ` (B${usuario.packDescription.match(/\d+/)}) : ''}`,
              emoji: '🌳',
              position: usuario.position,
              user_id: usuario.user_id,
              paquetesAdquiridos: usuario.paquetesAdquiridos,
              children: [],
            };
        
            if (nivel > 0) {
              // Si no hemos alcanzado la profundidad deseada
              if (usuario.referidos) {
                // Si hay referidos para este usuario
                const referidosLadoIzquierdo = usuario.referidos.filter(referido => referido.position === 1);
                const referidosLadoDerecho = usuario.referidos.filter(referido => referido.position === 2);
                
                if (referidosLadoIzquierdo.length === 0) {
                  const nodoVacioIzquierdo = {
                    name: "DISPONIBLE",
                    emoji: '🌳',
                    children: [],
                  };
                  usuarioNode.children.unshift(nodoVacioIzquierdo);
                }
                
                if (referidosLadoDerecho.length === 0) {
                  const nodoVacioDerecho = {
                    name: "DISPONIBLE",
                    emoji: '🌳',
                    children: [],
                  };
                  usuarioNode.children.push(nodoVacioDerecho);
                }
  
                // Verifica la posición del referente y el referido
                const esLadoIzquierdoReferido = usuario.position === 1;
  
                // Asegura que los referidos se asignen al lado correcto
                if (esLadoIzquierdoReferente) {
                  referidosLadoIzquierdo.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.unshift(referidoNode);
                  
                    }
  
           
                  });
  
                  referidosLadoDerecho.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.push(referidoNode);
                   
                    }
                  });
                } else {
                  referidosLadoDerecho.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.push(referidoNode);
            
                    }
  
                  });
  
                  referidosLadoIzquierdo.forEach((referido) => {
                    const referidoNode = construirArbol(referido, nivel - 1, esLadoIzquierdoReferido);
                    if (referidoNode) {
                      usuarioNode.children.unshift(referidoNode);
                  
                    }
                  });
                }
              }
            }
  
            return usuarioNode;
          }
  
          // Limitar la profundidad deseada
          const nivelProfundidadDeseado = 100; // Ajusta esto según tus necesidades
          response.data.usuarios.forEach((usuario) => {
            const usuarioNode = construirArbol(usuario, nivelProfundidadDeseado, false); // Inicia con falso
            if (usuarioNode) {
              treeData.children.unshift(usuarioNode);
             
            }
          });
        }
  
        setTreeData(treeData);
  
        // Actualiza los datos en binaryData
        const updatedBinaryData = [
       
          {
            key: "2",
            left: totalCostoPaquetesIzquierdo,
            center: "VOLUMEN DE RANGO",
            right: totalCostoPaquetesDerecho,
          },
          // Agrega más datos según tu estructura binaria
        ];
  
        setBinaryData(updatedBinaryData);
        console.log(updatedBinaryData);
      })
      .catch((error) => {
        console.error('Error al obtener el árbol binario:', error);
      });
  }, [userData]);
  

  const columns = [
    {
      title: "IZQUIERDA",
      dataIndex: "left",
      key: "left",
      align: "center", // Centra el contenido horizontalmente
    },
    {
      title: "ESTADÍSTICAS DE LA RED",
      dataIndex: "center",
      key: "center",
      align: "center", // Centra el contenido horizontalmente
    },
    {
      title: "DERECHA",
      dataIndex: "right",
      key: "right",
      align: "center", // Centra el contenido horizontalmente
    },
  ];

  
  return (
    <Layout className="hp-calendar hp-mb-32 hp-bg-dark-90">
      <Content>
        <Card>
          <Row>
            <Col flex="1 1" className="hp-py-24">
              <Table
                columns={columns}
                dataSource={binaryData}
                pagination={false}
                bordered={false}
              />
              <div style={{ width: '100%', height: '500px' }}>
                {treeData ? (
                  <Tree
                  data={treeData}
                  orientation="vertical"
                  initialDepth={2}
                  nodeSize={nodeSize}
                  allowForeignObjects
                  translate={{ x: 50, y: 50 }}
                  collapsible={true}
                 
                  scaleExtent={{ min: 0.1, max: 1.5 }}
                  separation={{ siblings: 1.5, nonSiblings: 2 }}
                  pathFunc="step"
                  transitionDuration={500}
                  nodeSvgShape={{
                    shape: 'none',
                   
                  }}
               
                  rootNodeClassName="node__root"
                    branchNodeClassName="node__branch"
                    leafNodeClassName="node__leaf"
                  />
                  
                ) : (
                  <p>Cargando datos del árbol...</p>
                )}
              </div>
            </Col>
          </Row>
        </Card>
      </Content>
    </Layout>
  );
}