import React, { useState, useEffect } from 'react';

const TablaDatos = () => {
  const [datos, setDatos] = useState([]);

  useEffect(() => {
    // Función para cargar datos desde el archivo JSON
    const cargarDatos = async () => {
      try {
        const response = await fetch('datos.json');
        const data = await response.json();
        setDatos(data);
      } catch (error) {
        console.error('Error al cargar los datos:', error);
      }
    };

    cargarDatos();
  }, []); // El segundo parámetro [] asegura que useEffect se ejecute solo una vez al montar el componente.

  return (
    <div>
      <h2>Tabla de Datos</h2>
      <table border="1">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Edad</th>
            <th>Ciudad</th>
          </tr>
        </thead>
        <tbody>
          {datos.map((dato, index) => (
            <tr key={index}>
              <td>{dato.nombre}</td>
              <td>{dato.edad}</td>
              <td>{dato.ciudad}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TablaDatos;
