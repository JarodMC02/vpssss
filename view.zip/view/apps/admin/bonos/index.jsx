import React, { useState } from 'react';
import { Container, Table, Form, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import moment from 'moment';
import { useSpring, animated } from 'react-spring';
import { FaExclamationTriangle } from 'react-icons/fa';

const PaymentForm = () => {
  const [data, setData] = useState({
    totalRoi: [],
    totalBinario: [],
  });

  const [newPayment, setNewPayment] = useState({
    date: '',
    primRoi: 0,
    segRoi: 0,
    calculatedPayment: 0,
  });

  const currentDate = moment().format('dddd, MMMM Do YYYY');

  const renderTable = (dataArr) => {
    return (
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Fecha</th>
            <th>Valor PrimRoi</th>
            <th>Valor SegRoi</th>
            <th>Resultado</th>
          </tr>
        </thead>
        <tbody>
          {dataArr.map((payment, index) => (
            <tr key={index}>
              <td>{payment.date}</td>
              <td>{payment.primRoi}</td>
              <td>{payment.segRoi}</td>
              <td style={{ color: payment.calculatedPayment === 0 ? 'red' : 'black' }}>
                {payment.calculatedPayment === 0 ? (
                  <span>
                    <FaExclamationTriangle /> {payment.calculatedPayment}
                  </span>
                ) : (
                  payment.calculatedPayment
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    );
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewPayment({ ...newPayment, [name]: value });
  };

  const handleAddPayment = () => {
    const total = newPayment.primRoi + newPayment.segRoi;
    const calculatedPayment = total * 0.5;

    const newData = {
      ...newPayment,
      calculatedPayment,
    };

    setData({
      ...data,
      totalRoi: [...data.totalRoi, newData],
    });

    setNewPayment({
      date: '',
      primRoi: 0,
      segRoi: 0,
      calculatedPayment: 0,
    });
  };

  const fadeAnimation = useSpring({
    opacity: 1,
    from: { opacity: 0 },
  });

  return (
    <animated.div style={fadeAnimation}>
      <Container style={{ marginTop: '20px' }}>
        <h2>Fecha General: {currentDate}</h2>

        <Form>
          <Form.Group controlId="formDate">
            <Form.Label>Fecha</Form.Label>
            <Form.Control
              type="text"
              placeholder="Ingrese la fecha"
              name="date"
              value={newPayment.date}
              onChange={handleInputChange}
            />
          </Form.Group>
          <Form.Group controlId="formPrimRoi">
            <Form.Label>Valor PrimRoi</Form.Label>
            <Form.Control
              type="number"
              placeholder="Ingrese el valor PrimRoi"
              name="primRoi"
              value={newPayment.primRoi}
              onChange={handleInputChange}
            />
          </Form.Group>
          <Form.Group controlId="formSegRoi">
            <Form.Label>Valor SegRoi</Form.Label>
            <Form.Control
              type="number"
              placeholder="Ingrese el valor SegRoi"
              name="segRoi"
              value={newPayment.segRoi}
              onChange={handleInputChange}
            />
          </Form.Group>
          <Button variant="primary" onClick={handleAddPayment}>
            Agregar Pago
          </Button>
        </Form>

        <h3>Tabla ROI</h3>
        {renderTable(data.totalRoi)}
      </Container>
    </animated.div>
  );
};

export default PaymentForm;
