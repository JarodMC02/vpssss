// UserTable.js
import React from "react";
import { Table } from "antd";

const UserTable = ({ data }) => {
  const columns = [
    { title: "Porcentaje de Pago", dataIndex: "porcentajePago", key: "porcentajePago" },
    { title: "Día de Pago", dataIndex: "diaPago", key: "diaPago" },
    { title: "Porcentaje de ROI", dataIndex: "porcentajeROI", key: "porcentajeROI" },
    { title: "Fecha de Validación", dataIndex: "fechaSeleccionada", key: "fechaSeleccionada" },
    { title: "Total", dataIndex: "total", key: "total" }, // New column for total
  ];

  return (
    <Table columns={columns} dataSource={data} pagination={{ pageSize: 5 }} />
  );
};

export default UserTable;
